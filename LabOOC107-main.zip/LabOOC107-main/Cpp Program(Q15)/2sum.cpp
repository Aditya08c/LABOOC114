// 2) Write a C++ program to input two numbers and display their sum.

#include <iostream>
using namespace std;

int main()
{
    int a, b, sum;

    cout << "Enter first number: ";
    cin >> a;
    cout << "Enter second number:";
    cin >> b;

    sum = a + b;

    cout << "Sum = " << sum << endl;

    return 0;
}