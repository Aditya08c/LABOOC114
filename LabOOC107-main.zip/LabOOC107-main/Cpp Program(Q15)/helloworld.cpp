// 1) Write a C++ program to print "Hello World".

#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World";
    return 0;
}